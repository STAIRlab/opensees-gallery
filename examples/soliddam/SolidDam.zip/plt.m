%test by Lei in Oct. 2018

clear all 
close all
clc
load ddm_disp_dam1_190.out
load node_dam190dispG1.dat
load node_dam190dispG2.dat
load node_dam190dispG3.dat
load node_dam190dispG4.dat
load node_dam190dispG5.dat
load node_dam_disp_190.dat
ax=gca;

set(ax, 'FontSize',26)
set(0,'defaultaxesfontsize',26);

plot(ddm_disp_dam1_190(:,1),ddm_disp_dam1_190(:,2),'k')
hold on
plot(ddm_disp_dam1_190(:,1),(node_dam190dispG1(:,2)-node_dam_disp_190(:,2))/0.1/1.2931e+10,'b-')
plot(ddm_disp_dam1_190(:,1),(node_dam190dispG2(:,2)-node_dam_disp_190(:,2))/0.01/1.2931e+10,'y--')
plot(ddm_disp_dam1_190(:,1),(node_dam190dispG3(:,2)-node_dam_disp_190(:,2))/0.001/1.2931e+10,'m:')
plot(ddm_disp_dam1_190(:,1),(node_dam190dispG4(:,2)-node_dam_disp_190(:,2))/0.0001/1.2931e+10,'r-')
plot(ddm_disp_dam1_190(:,1),(node_dam190dispG5(:,2)-node_dam_disp_190(:,2))/0.00001/1.2931e+10,'b:')


h=legend('DDM','FFD 0.1','FFD 0.01','FFD 0.001','FFD 0.0001','FFD 0.00001');
set(h,'Fontsize',8);
xlabel('Time [Sec]','Fontsize',26)
ylabel('\partialu_1/\partialG','Fontsize',26)
 



