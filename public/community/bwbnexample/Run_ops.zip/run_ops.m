clc;
clear;

EQrec = zeros(10,1);
EQrec(1)=143;
EQrec(2)=169;
EQrec(3)=284;
EQrec(4)=719;
EQrec(5)=804;
EQrec(6)=880;
EQrec(7)=1153;
EQrec(8)=1511;
EQrec(9)=1838;
EQrec(10)=2112;


Sarec = zeros(28,1);
for i=1:20
    Sarec(i)=i/10.0;
end
Sarec(21)=0.72;
Sarec(22)=0.13;
Sarec(23)=0.15;
Sarec(24)=0.18;
Sarec(25)=0.02;
Sarec(26)=0.04;
Sarec(27)=0.06;
Sarec(28)=0.08;

SaID = zeros(28,1);
for i=1:20
    SaID(i)=i;
end
SaID(21)=72;
SaID(22)=13;
SaID(23)=15;
SaID(24)=18;
SaID(25)=2;
SaID(26)=4;
SaID(27)=6;
SaID(28)=8;

for i=2:2
    
   for j=1:28
      
          
       if j>9 && j<21
       fFN1=sprintf('%dFN%d',EQrec(i),SaID(j));
       elseif j<25
       fFN1=sprintf('%dFN0%d',EQrec(i),SaID(j));
       else
       fFN1=sprintf('%dFN00%d',EQrec(i),SaID(j));
       end
       
       fid=fopen('Model.tcl','w');
       fprintf(fid,'wipe;\n');
       fprintf(fid,'source SACgravity.tcl;\n');
       fprintf(fid,'source SACeqscale.tcl;\n');
       fprintf(fid,'recorder Drift -file %s_DriftStory1.out -time -iNode 1 -jNode 7 -dof 1 -perpDirn 2;\n',fFN1);
       fprintf(fid,'recorder Drift -file %s_DriftStory2.out -time -iNode 7 -jNode 13 -dof 1 -perpDirn 2;\n',fFN1);
       fprintf(fid,'recorder Drift -file %s_DriftStory3.out -time -iNode 13 -jNode 19 -dof 1 -perpDirn 2;\n',fFN1);
       fprintf(fid,'recorder Drift -file %s_DriftTotal.out -time -iNode 1 -jNode 19 -dof 1 -perpDirn 2;\n',fFN1);
       fprintf(fid,'recorder Node -file %s_Disp.out -time -node 7 13 19 -dof 1 disp;\n',fFN1);
       fprintf(fid,'recorder Node -file %s_Vbase.out -time -node 1 2 3 4 5 6 -dof 1 reaction;\n',fFN1);
       fprintf(fid,'set GMfile \"%d_FN.acc\";\n',EQrec(i));
       fprintf(fid,'set dt [expr $%dFNdt];\n',EQrec(i));
       fprintf(fid,'set TotalNumberOfSteps [expr $%dFNnpts];\n',EQrec(i));
       fprintf(fid,'set Scalefact [expr $%s];\n',fFN1);
       fprintf(fid,'source SACdynamicals.tcl;\n');
       fclose(fid);
       dos('opensees model.tcl');

       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
       if j>9 && j<21
       fFP1=sprintf('%dFP%d',EQrec(i),SaID(j));
       elseif j<25
       fFP1=sprintf('%dFP0%d',EQrec(i),SaID(j));
       else
       fFP1=sprintf('%dFP00%d',EQrec(i),SaID(j));
       end
       
       fid=fopen('Model.tcl','w');
       fprintf(fid,'wipe;\n');
       fprintf(fid,'source SACgravity.tcl;\n');
       fprintf(fid,'source SACeqscale.tcl;\n');
       fprintf(fid,'recorder Drift -file %s_DriftStory1.out -time -iNode 1 -jNode 7 -dof 1 -perpDirn 2;\n',fFP1);
       fprintf(fid,'recorder Drift -file %s_DriftStory2.out -time -iNode 7 -jNode 13 -dof 1 -perpDirn 2;\n',fFP1);
       fprintf(fid,'recorder Drift -file %s_DriftStory3.out -time -iNode 13 -jNode 19 -dof 1 -perpDirn 2;\n',fFP1);
       fprintf(fid,'recorder Drift -file %s_DriftTotal.out -time -iNode 1 -jNode 19 -dof 1 -perpDirn 2;\n',fFP1);
       fprintf(fid,'recorder Node -file %s_Disp.out -time -node 7 13 19 -dof 1 disp;\n',fFP1);
       fprintf(fid,'recorder Node -file %s_Vbase.out -time -node 1 2 3 4 5 6 -dof 1 reaction;\n',fFP1);
       fprintf(fid,'set GMfile \"%d_FP.acc\";\n',EQrec(i));
       fprintf(fid,'set dt [expr $%dFPdt];\n',EQrec(i));
       fprintf(fid,'set TotalNumberOfSteps [expr $%dFPnpts];\n',EQrec(i));
       fprintf(fid,'set Scalefact [expr $%s];\n',fFP1);
       fprintf(fid,'source SACdynamicals.tcl;\n');
       fclose(fid);
       dos('opensees model.tcl');
    
            
      
   end
end

