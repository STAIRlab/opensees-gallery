clc;
clear;


EQrec = zeros(10,1);
EQrec(1)=143;
EQrec(2)=169;
EQrec(3)=284;
EQrec(4)=719;
EQrec(5)=804;
EQrec(6)=880;
EQrec(7)=1153;
EQrec(8)=1511;
EQrec(9)=1838;
EQrec(10)=2112;


Sarec = zeros(28,1);
for i=1:20
    Sarec(i)=i/10.0;
end
Sarec(21)=0.72;
Sarec(22)=0.13;
Sarec(23)=0.15;
Sarec(24)=0.18;
Sarec(25)=0.02;
Sarec(26)=0.04;
Sarec(27)=0.06;
Sarec(28)=0.08;

SaID = zeros(28,1);
for i=1:20
    SaID(i)=i;
end
SaID(21)=72;
SaID(22)=13;
SaID(23)=15;
SaID(24)=18;
SaID(25)=2;
SaID(26)=4;
SaID(27)=6;
SaID(28)=8;

for i=1:10
    
   for j=1:28
       
       s1=sprintf('A%d:A%d',(i-1)*28+j+1,(i-1)*28+j+1);
       xlswrite('Driftmax_1.xlsx',EQrec(i),'Sheet1',s1);
       s1=sprintf('C%d:C%d',(i-1)*28+j+1,(i-1)*28+j+1);
       xlswrite('Driftmax_1.xlsx',Sarec(j),'Sheet1',s1);
            
       if j>9 && j<21
       fFN1=sprintf('%dFN%d_DriftStory1.out',EQrec(i),SaID(j));
       fFN2=sprintf('%dFN%d_DriftStory2.out',EQrec(i),SaID(j));
       fFN3=sprintf('%dFN%d_DriftStory3.out',EQrec(i),SaID(j));
       elseif j<25
       fFN1=sprintf('%dFN0%d_DriftStory1.out',EQrec(i),SaID(j));
       fFN2=sprintf('%dFN0%d_DriftStory2.out',EQrec(i),SaID(j));
       fFN3=sprintf('%dFN0%d_DriftStory3.out',EQrec(i),SaID(j));
       else
       fFN1=sprintf('%dFN00%d_DriftStory1.out',EQrec(i),SaID(j));
       fFN2=sprintf('%dFN00%d_DriftStory2.out',EQrec(i),SaID(j));
       fFN3=sprintf('%dFN00%d_DriftStory3.out',EQrec(i),SaID(j));
       end
       
       
       [T1,D1]=textread(fFN1,'%f %f');
       [T2,D2]=textread(fFN2,'%f %f');
       [T3,D3]=textread(fFN3,'%f %f');
       
       m1 = max(max(D1),abs(min(D1)));
       m2 = max(max(D2),abs(min(D2)));
       m3 = max(max(D3),abs(min(D3)));
       m4 = max(m1,m2);
       mdrift = max(m3,m4);
       
       s1=sprintf('D%d:D%d',(i-1)*28+j+1,(i-1)*28+j+1);
       xlswrite('Driftmax_1.xlsx',mdrift,'Sheet1',s1);
       
       s1=sprintf('F%d:F%d',(i-1)*28+j+1,(i-1)*28+j+1);
       xlswrite('Driftmax_1.xlsx',EQrec(i),'Sheet1',s1);
       s1=sprintf('H%d:H%d',(i-1)*28+j+1,(i-1)*28+j+1);
       xlswrite('Driftmax_1.xlsx',Sarec(j),'Sheet1',s1);
       
       if j>9 && j<21
       fFP1=sprintf('%dFP%d_DriftStory1.out',EQrec(i),SaID(j));
       fFP2=sprintf('%dFP%d_DriftStory2.out',EQrec(i),SaID(j));
       fFP3=sprintf('%dFP%d_DriftStory3.out',EQrec(i),SaID(j));
       elseif j<25
       fFP1=sprintf('%dFP0%d_DriftStory1.out',EQrec(i),SaID(j));
       fFP2=sprintf('%dFP0%d_DriftStory2.out',EQrec(i),SaID(j));
       fFP3=sprintf('%dFP0%d_DriftStory3.out',EQrec(i),SaID(j));
       else
       fFP1=sprintf('%dFP00%d_DriftStory1.out',EQrec(i),SaID(j));
       fFP2=sprintf('%dFP00%d_DriftStory2.out',EQrec(i),SaID(j));
       fFP3=sprintf('%dFP00%d_DriftStory3.out',EQrec(i),SaID(j));
       end    
           
       [T1,D1]=textread(fFP1,'%f %f');
       [T2,D2]=textread(fFP2,'%f %f');
       [T3,D3]=textread(fFP3,'%f %f');
       
       m1 = max(max(D1),abs(min(D1)));
       m2 = max(max(D2),abs(min(D2)));
       m3 = max(max(D3),abs(min(D3)));
       m4 = max(m1,m2);
       mdrift = max(m3,m4);
       
       s1=sprintf('I%d:I%d',(i-1)*28+j+1,(i-1)*28+j+1);
       xlswrite('Driftmax_1.xlsx',mdrift,'Sheet1',s1);
            
      
   end
end

